package gui;

import java.awt.EventQueue;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import businessLogic.BLFacade;
import domain.Message;
import domain.Movement;
import domain.User;
import domain.UserAbstract;
import domain.UserAdmin;

import javax.swing.JList;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.Color;

public class SendMessageGUI extends JFrame {

	private JPanel contentPane;
	private JList list = new JList();
	private DefaultListModel<Message> model = new DefaultListModel<Message>();
	private JComboBox comboBoxMessage;
	private DefaultComboBoxModel modelbox= new DefaultComboBoxModel();
	private JLabel lblReceiver;
	private JTextArea messagearea;
	private JButton sendBtton = new JButton(ResourceBundle.getBundle("Etiquetas").getString("Send"));
	private JLabel labelerror= new JLabel();
	private JLabel labeltestu;
	private JButton backBttn;
	private JScrollPane scrollPane;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SendMessageGUI frame = new SendMessageGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SendMessageGUI() {
		this.setTitle(ResourceBundle.getBundle("Etiquetas").getString("ChatBtton"));
		sendBtton.setEnabled(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		

		setContentPane(contentPane);
		contentPane.setLayout(null);
		BLFacade business= MainGUI.getBusinessLogic();
		UserAbstract u = MainGUI.getUser();
		list.setBounds(47, 37, 332, 127);
		list.setModel(model);
		
		comboBoxMessage = new JComboBox();
		if(u instanceof UserAdmin) {
			modelbox.addAll(business.getUsers(false));
		}else {
			modelbox.addAll(business.getUsers(true));
		}
		comboBoxMessage.setModel(modelbox);
		comboBoxMessage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				model.removeAllElements();
				if (u instanceof UserAdmin) {
					model.addAll(business.getMessages((User)comboBoxMessage.getSelectedItem(),(UserAdmin)u));
				}else {
					model.addAll(business.getMessages((User)u, (UserAdmin)comboBoxMessage.getSelectedItem()));
				}
				sendBtton.setEnabled(true);
			}
		});
		comboBoxMessage.setBounds(159, 6, 220, 21);
		contentPane.add(comboBoxMessage);
		
		lblReceiver = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("Receiver"));
		lblReceiver.setBounds(47, 10, 131, 13);
		contentPane.add(lblReceiver);
		
		messagearea = new JTextArea();
		messagearea.setBounds(47, 188, 286, 65);
		contentPane.add(messagearea);
		sendBtton.setBackground(new Color(0, 0, 0));
		sendBtton.setForeground(new Color(255, 255, 255));
		sendBtton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (messagearea.getText().length()==0) {
					labelerror.setText("Ez dago testua idatzita");
				}else {
					Message message;
					if (u instanceof UserAdmin) {
						 message= new Message((UserAdmin)u,(User)comboBoxMessage.getSelectedItem(), messagearea.getText() );
						 business.sendMessage((User)comboBoxMessage.getSelectedItem(),(UserAdmin)u, message);
					}else {
						 message= new Message((User)u,(UserAdmin)comboBoxMessage.getSelectedItem(), messagearea.getText() );
						 business.sendMessage((User)u,(UserAdmin)comboBoxMessage.getSelectedItem(), message);
					}
					model.addElement(message);
					list.setModel(model);
				}
			}
			
		});
		
		sendBtton.setBounds(343, 188, 85, 29);
		contentPane.add(sendBtton);
		
		labelerror.setBounds(47, 204, 316, 13);
		contentPane.add(labelerror);
		
		labeltestu = new JLabel(ResourceBundle.getBundle("Etiquetas").getString("lbltestua"));
		labeltestu.setBounds(47, 165, 131, 13);
		contentPane.add(labeltestu);
		
		backBttn = new JButton(ResourceBundle.getBundle("Etiquetas").getString("BackQuote"));
		backBttn.setForeground(new Color(0, 0, 0));
		backBttn.setBackground(new Color(255, 255, 255));
		backBttn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (u instanceof UserAdmin) {
					AdminGUI admin = new AdminGUI();
					admin.setVisible(true);
					SendMessageGUI.this.setVisible(false);
				}else {
					MenuGUI menu = new MenuGUI();
					menu.setVisible(true);
					SendMessageGUI.this.setVisible(false);
				}
			}
		});
		backBttn.setBounds(343, 227, 85, 26);
		contentPane.add(backBttn);
		
		scrollPane = new JScrollPane();
		scrollPane.setViewportView(list);
		scrollPane.setBounds(47, 37, 332, 127);
		contentPane.add(scrollPane);
		}
}
