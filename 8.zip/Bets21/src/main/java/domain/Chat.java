package domain;

import java.util.Vector;
import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Chat {
	@XmlID @Id @GeneratedValue @XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer id;
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private Vector<Message> messages;
	//@XmlIDREF
	private User us1;
	//@XmlIDREF
	private UserAdmin us2;
	public User getUsNormal() {
		return us1;
	}
	
	public Chat() {
		super();
	}

	public void setUsNormal(User us1) {
		this.us1 = us1;
	}

	public UserAdmin getUsAdmin() {
		return us2;
	}

	public void setUsAdmin(UserAdmin us2) {
		this.us2 = us2;
	}
	public Chat(User us1, UserAdmin us2) {
		messages=new Vector<Message>();
		this.us1= us1;
		this.us2= us2;
	}
	
	public Vector<Message> getMessages() {
		return messages;
	}

	public void setMessages(Vector<Message> messages) {
		this.messages = messages;
	}
}
