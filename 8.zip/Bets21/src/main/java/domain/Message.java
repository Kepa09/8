package domain;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity @XmlAccessorType(XmlAccessType.FIELD)
public class Message {
	@Id @GeneratedValue @XmlID	@XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer id;
	//@XmlIDREF
	private UserAbstract nork;
	//@XmlIDREF
	private UserAbstract nori;
	private String zer;
	public Message(UserAbstract nork, UserAbstract nori, String zer) {
		this.nori= nori;
		this.nork=nork;
		this.zer= zer;
	}
	
	public Message() {
		super();
	}
	
	public UserAbstract getNork() {
		return nork;
		
	}
	public void setNork(UserAdmin nork) {
		this.nork = nork;
	}
	public UserAbstract getNori() {
		return nori;
	}
	public void setNori(UserAbstract nori) {
		this.nori = nori;
	}
	public String getZer() {
		return zer;
	}
	public void setZer(String zer) {
		this.zer = zer;
	}
	@Override
	public String toString() {
		return  nork  + ": " + zer;
	}
	
}
