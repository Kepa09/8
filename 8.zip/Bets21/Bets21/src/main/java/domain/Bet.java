package domain;

import java.util.Objects;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.XmlIDREF;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Bet {
	@XmlID @GeneratedValue @Id @XmlJavaTypeAdapter(IntegerAdapter.class)
	private Integer number;
	private float kop;
	//@XmlIDREF
	private User user;
	@XmlIDREF
	private Quote quote;
	
	public Bet(float kop, User user, Quote quote) {
		this.kop=kop;
		this.user=user;
		this.quote=quote;
	}
	public Bet() {
		super();
	}
	public float getKop() {
		return kop;
	}
	public void setKop(float kop) {
		this.kop = kop;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Quote getQuote() {
		return quote;
	}
	public void setQuote(Quote quote) {
		this.quote = quote;
	}
	public void remove() {
		user.removeBet(this);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bet other = (Bet) obj;
		return number == other.number;
	}
}
