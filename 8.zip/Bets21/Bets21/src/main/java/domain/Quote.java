package domain;

import java.util.Vector;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlID;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@Entity
@XmlAccessorType(XmlAccessType.FIELD)
public class Quote {
	@XmlJavaTypeAdapter(IntegerAdapter.class)
	@XmlID @GeneratedValue @Id
	private Integer quoteNumber;
	private String quote;
	private double multi;
	@OneToMany(fetch=FetchType.EAGER, cascade=CascadeType.ALL)
	private Vector<Bet> bets = new Vector<Bet>();
	private boolean isWinner= false;

	
	public Quote(String quote, double multi) {
		this.quote = quote;
		this.multi = multi;
		 bets = new Vector<Bet>();
	}
	
	public Quote() {
		super();
	}

	public String getQuote() {
		return quote;
	}

	public void setQuote(String quote) {
		this.quote = quote;
	}

	public double getMulti() {
		return multi;
	}

	public void setMulti(double multi) {
		this.multi = multi;
	}

	public Vector<Bet> getBets() {
		return bets;
	}

	public void setBets(Vector<Bet> bets) {
		this.bets = bets;
	}
	public void makeWinner() {
		isWinner = true;
	}
	public boolean isWinner() {
		return isWinner;
	}

	public String toString() {
        return quote + ", x" + multi;
    }
	public void removeBets() {
		for (Bet b: this.getBets()) {
			b.remove();
		}
	}
}
