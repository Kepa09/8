package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;
import java.awt.event.ActionEvent;

public class MenuGUI extends JFrame {

    private JPanel contentPane;
    private JButton ReturnBtton= new JButton(ResourceBundle.getBundle("Etiquetas").getString("ReturnBtton"));
    private JButton WalletBtton = new JButton(ResourceBundle.getBundle("Etiquetas").getString("WalletBtton"));
    private JButton BetBtton = new JButton(ResourceBundle.getBundle("Etiquetas").getString("BetBtton"));
    JButton SeeMovementsBtton = new JButton(ResourceBundle.getBundle("Etiquetas").getString("SeeMovementsBtton")); //$NON-NLS-1$ //$NON-NLS-2$

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MenuGUI frame = new MenuGUI();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public MenuGUI() {
    	this.setTitle(ResourceBundle.getBundle("Etiquetas").getString("Menu"));
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

        setContentPane(contentPane);
        contentPane.setLayout(null);
BetBtton.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		BetGUI bet= new BetGUI();
		bet.setVisible(true);
		MenuGUI.this.setVisible(false);
		
	}
});

BetBtton.setForeground(new Color(255, 255, 255));
        BetBtton.setBackground(new Color(0, 0, 0));
        BetBtton.setBounds(10, 26, 150, 49);
        contentPane.add(BetBtton);
        WalletBtton.setBackground(Color.BLACK);
        WalletBtton.setForeground(Color.WHITE);

        WalletBtton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	WalletGUI wallet= new WalletGUI();
            	wallet.setVisible(true);
            	MenuGUI.this.setVisible(false);
            	
            }
        });
        WalletBtton.setBounds(252, 26, 145, 49);
        contentPane.add(WalletBtton);
        ReturnBtton.setBackground(Color.white);
        ReturnBtton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainGUI main=new MainGUI();
                main.setVisible(true);
                MenuGUI.this.setVisible(false);
            }
        });
        ReturnBtton.setBounds(137, 203, 145, 50);
        contentPane.add(ReturnBtton);
        SeeMovementsBtton.setForeground(Color.WHITE);
        SeeMovementsBtton.setBackground(Color.BLACK);


        SeeMovementsBtton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	MovementsGUI movements=new MovementsGUI();
                movements.setVisible(true);
                MenuGUI.this.setVisible(false);
            }
        });
        SeeMovementsBtton.setBounds(10, 98, 150, 49);
        contentPane.add(SeeMovementsBtton);
        
        JButton FindQuestionsbtton = new JButton(ResourceBundle.getBundle("Etiquetas").getString("FindQuestion")); //$NON-NLS-1$ //$NON-NLS-2$
        FindQuestionsbtton.setForeground(Color.WHITE);
        FindQuestionsbtton.setBackground(Color.BLACK);
        FindQuestionsbtton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		FindQuestionsGUI  findquestions= new FindQuestionsGUI();
        		findquestions.setVisible(true);
        		MenuGUI.this.setVisible(false);
        	
        	}
        });
        FindQuestionsbtton.setBounds(252, 98, 145, 49);
        contentPane.add(FindQuestionsbtton);
    }
}